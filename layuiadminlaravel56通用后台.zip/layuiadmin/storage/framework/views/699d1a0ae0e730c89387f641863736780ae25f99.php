<?php $__env->startSection('content'); ?>
    <h1>
        <span class="layui-anim layui-anim-loop layui-anim-">4</span>
        <span class="layui-anim layui-anim-loop layui-anim-rotate">0</span>
        <span class="layui-anim layui-anim-loop layui-anim-">4</span>
    </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>