<?php
return [
    //推送消息请求地址
//    'PUSH_MESSAGE_URL' => 'http://192.168.254.31:2121',
    'PUSH_MESSAGE_URL' => 'http://',
    //推送消息登录地址
//    'PUSH_MESSAGE_LOGIN' => 'http://192.168.254.31:2120',
    'PUSH_MESSAGE_LOGIN' => 'http://',
];