@extends('errors.base')

@section('content')
    <h1>
        <span class="layui-anim layui-anim-loop layui-anim-">4</span>
        <span class="layui-anim layui-anim-loop layui-anim-rotate">0</span>
        <span class="layui-anim layui-anim-loop layui-anim-">4</span>
    </h1>
@endsection
