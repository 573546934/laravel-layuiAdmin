@extends('errors.base')

@section('content')
    <h2>无权限访问</h2>
@endsection
